package com.cte.tech.util;

/**
 * Created by liunan
 */
public class CTECryptoAESException extends Exception {

    public CTECryptoAESException(String message, Exception e) {
        super(message, e);

    }
}
